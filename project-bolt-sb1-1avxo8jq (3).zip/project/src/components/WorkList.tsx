import React, { useState } from 'react';
import { WorkEntry } from '../types';
import { format, startOfMonth, endOfMonth, subMonths, addMonths, isWithinInterval } from 'date-fns';

interface WorkListProps {
  entries: WorkEntry[];
}

export function WorkList({ entries }: WorkListProps) {
  const [selectedMonth, setSelectedMonth] = useState(new Date());

  const handlePrevMonth = () => {
    setSelectedMonth((prev) => subMonths(prev, 1));
  };

  const handleNextMonth = () => {
    setSelectedMonth((prev) => addMonths(prev, 1));
  };

  const filteredEntries = entries.filter((entry) =>
    isWithinInterval(entry.date, {
      start: startOfMonth(selectedMonth),
      end: endOfMonth(selectedMonth),
    })
  );

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <h2 className="text-2xl font-bold p-6 border-b">明細</h2>
      <div className="flex justify-between items-center px-6 py-4">
        <button
          onClick={handlePrevMonth}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
        >
          &lt; 前の月
        </button>
        <p className="text-lg font-medium">
          {format(selectedMonth, 'yyyy年MM月')}
        </p>
        <button
          onClick={handleNextMonth}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
        >
          次の月 &gt;
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">日付</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">会社名</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">時間</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">時給</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">合計</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredEntries.map((entry) => (
              <tr key={entry.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  {format(entry.date, 'yyyy年MM月dd日')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">{entry.companyName}</td>
                <td className="px-6 py-4 whitespace-nowrap">{entry.hoursWorked}</td>
                <td className="px-6 py-4 whitespace-nowrap">¥{Math.round(entry.wages).toLocaleString()}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  ¥{Math.round(entry.hoursWorked * entry.wages).toLocaleString()}
                </td>
              </tr>
            ))}
            {filteredEntries.length === 0 && (
              <tr>
                <td colSpan={5} className="text-center py-6 text-gray-500">
                  この月のデータがありません。
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
