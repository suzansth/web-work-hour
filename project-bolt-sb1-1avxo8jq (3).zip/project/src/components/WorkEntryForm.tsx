import React, { useState } from 'react';
import { WorkEntry } from '../types';
import { CalendarDays, Building2, Clock, Coins } from 'lucide-react';

interface WorkEntryFormProps {
  onSubmit: (entry: WorkEntry) => void;
}

export function WorkEntryForm({ onSubmit }: WorkEntryFormProps) {
  const [formData, setFormData] = useState({
    date: '',
    companyName: '',
    hoursWorked: '',
    wages: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      id: Date.now().toString(),
      date: new Date(formData.date),
      companyName: formData.companyName,
      hoursWorked: Number(formData.hoursWorked),
      wages: Number(formData.wages)
    });
    setFormData({ date: '', companyName: '', hoursWorked: '', wages: '' });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">内容をイントリ</h2>
      
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <CalendarDays className="text-gray-500" />
          <input
            type="date"
            value={formData.date}
            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            className="flex-1 p-2 border rounded-md"
            required
          />
        </div>

        <div className="flex items-center space-x-2">
          <Building2 className="text-gray-500" />
          <input
            type="text"
            placeholder="会社名"
            value={formData.companyName}
            onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
            className="flex-1 p-2 border rounded-md"
            required
          />
        </div>

        <div className="flex items-center space-x-2">
          <Clock className="text-gray-500" />
          <input
            type="number"
            step="0.5"
            placeholder="時間"
            value={formData.hoursWorked}
            onChange={(e) => setFormData({ ...formData, hoursWorked: e.target.value })}
            className="flex-1 p-2 border rounded-md"
            required
          />
        </div>

        <div className="flex items-center space-x-2">
          <Coins className="text-gray-500" />
          <input
            type="number"
            step="0.01"
            placeholder="時給"
            value={formData.wages}
            onChange={(e) => setFormData({ ...formData, wages: e.target.value })}
            className="flex-1 p-2 border rounded-md"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
        >
          追加
        </button>
      </div>
    </form>
  );
}