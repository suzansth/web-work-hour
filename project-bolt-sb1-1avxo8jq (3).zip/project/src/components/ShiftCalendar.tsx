import React, { useState } from 'react';
import Calendar from 'react-calendar';
import { WorkShift } from '../types';
import { format, addDays, addWeeks, isSameDay } from 'date-fns';
import { ja } from 'date-fns/locale';
import { Trash2 } from 'lucide-react';
import 'react-calendar/dist/Calendar.css';

interface ShiftCalendarProps {
  shifts: WorkShift[];
  onAddShift: (shift: WorkShift) => void;
  selectedMonth: Date;
  onMonthChange: (date: Date) => void;
}

export function ShiftCalendar({ shifts, onAddShift, selectedMonth, onMonthChange }: ShiftCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [newShift, setNewShift] = useState({
    startTime: '',
    endTime: '',
    companyName: ''
  });

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDate) {
      onAddShift({
        date: selectedDate,
        ...newShift
      });
      // Keep the form open for adding multiple shifts
      setNewShift({ startTime: '', endTime: '', companyName: '' });
    }
  };

  const tileContent = ({ date }: { date: Date }) => {
    const dayShifts = shifts.filter(s => isSameDay(s.date, date));
    
    if (dayShifts.length === 0) return null;

    return (
      <div className="text-xs mt-1 space-y-1 max-h-[60px] overflow-y-auto">
        {dayShifts.map((shift, index) => (
          <div key={index} className="bg-blue-50 p-1 rounded">
            <div className="font-semibold text-blue-600">{shift.companyName}</div>
            <div className="text-gray-600">
              {shift.startTime} - {shift.endTime}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">勤務スケジュール</h2>
        <button
          onClick={() => {
            setSelectedDate(new Date());
            setShowForm(true);
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
        >
          シフトを追加
        </button>
      </div>
      
      <div className="calendar-container mb-6">
        <Calendar
          onChange={handleDateClick}
          value={selectedDate}
          onActiveStartDateChange={({ activeStartDate }) => {
            if (activeStartDate) {
              onMonthChange(activeStartDate);
            }
          }}
          tileContent={tileContent}
          locale="ja-JP"
          className="rounded-lg border-0 w-full"
        />
      </div>

      {showForm && (
        <div className="mt-6 p-4 border rounded-lg bg-gray-50">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">
              {selectedDate && format(selectedDate, 'yyyy年MM月dd日', { locale: ja })}
              のシフト追加
            </h3>
            <button
              onClick={() => setShowForm(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">会社名</label>
              <input
                type="text"
                value={newShift.companyName}
                onChange={(e) => setNewShift({ ...newShift, companyName: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">開始時間</label>
                <input
                  type="time"
                  value={newShift.startTime}
                  onChange={(e) => setNewShift({ ...newShift, startTime: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">終了時間</label>
                <input
                  type="time"
                  value={newShift.endTime}
                  onChange={(e) => setNewShift({ ...newShift, endTime: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
            </div>
            <div className="flex justify-between">
              <button
                type="submit"
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
              >
                追加して続ける
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300"
              >
                完了
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}