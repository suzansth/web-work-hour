import React, { useState } from 'react';
import { WorkEntry } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { format, subMonths, startOfMonth, endOfMonth, isWithinInterval, addMonths } from 'date-fns';
import { ja } from 'date-fns/locale';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface MonthlyStatsProps {
  entries: WorkEntry[];
  selectedMonth: Date;
  allEntries: WorkEntry[];
  onMonthChange: (date: Date) => void;
}

export function MonthlyStats({ entries, selectedMonth, allEntries, onMonthChange }: MonthlyStatsProps) {
  const [viewType, setViewType] = useState<'monthly' | 'total'>('monthly');

  const totalHours = entries.reduce((sum, entry) => sum + entry.hoursWorked, 0);
  const totalIncome = entries.reduce((sum, entry) => sum + (entry.hoursWorked * entry.wages), 0);

  const totalAllHours = allEntries.reduce((sum, entry) => sum + entry.hoursWorked, 0);
  const totalAllIncome = allEntries.reduce((sum, entry) => sum + (entry.hoursWorked * entry.wages), 0);

  const dailyData = (viewType === 'monthly' ? entries : allEntries).reduce((acc: any[], entry) => {
    const date = format(entry.date, 'MM/dd');
    const existing = acc.find(item => item.date === date);
    
    if (existing) {
      existing.hours += entry.hoursWorked;
      existing.income += entry.hoursWorked * entry.wages;
    } else {
      acc.push({ 
        date, 
        hours: entry.hoursWorked,
        income: entry.hoursWorked * entry.wages
      });
    }
    
    return acc;
  }, []);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 shadow-lg rounded-lg border">
          <p className="text-sm font-semibold">{label}</p>
          <p className="text-sm text-blue-600">労働時間: {payload[0].value}時間</p>
          <p className="text-sm text-green-600">収入: ¥{Math.round(payload[1].value).toLocaleString()}</p>
        </div>
      );
    }
    return null;
  };

  const handlePrevMonth = () => {
    onMonthChange(subMonths(selectedMonth, 1));
  };

  const handleNextMonth = () => {
    onMonthChange(addMonths(selectedMonth, 1));
  };

  const handleCurrentMonth = () => {
    onMonthChange(startOfMonth(new Date()));
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">
          {format(selectedMonth, 'yyyy年MM月', { locale: ja })}の統計
        </h2>
        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrevMonth}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleCurrentMonth}
            className="px-3 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
          >
            今月
          </button>
          <button
            onClick={handleNextMonth}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex justify-center mb-4">
        <button
          onClick={() => setViewType('monthly')}
          className={`px-4 py-2 mx-2 rounded-md ${
            viewType === 'monthly'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          月次データ
        </button>
        <button
          onClick={() => setViewType('total')}
          className={`px-4 py-2 mx-2 rounded-md ${
            viewType === 'total'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          全体データ
        </button>
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={dailyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis yAxisId="left" orientation="left" stroke="#3b82f6" />
            <YAxis yAxisId="right" orientation="right" stroke="#10b981" />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar yAxisId="left" dataKey="hours" name="労働時間" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            <Bar yAxisId="right" dataKey="income" name="収入" fill="#10b981" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 gap-6 mt-8">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold text-blue-800">
            {viewType === 'monthly' ? '今月の総労働時間' : '全体の総労働時間'}
          </h3>
          <p className="text-3xl font-bold text-blue-600">
            {viewType === 'monthly' ? totalHours.toFixed(1) : totalAllHours.toFixed(1)}時間
          </p>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold text-green-800">
            {viewType === 'monthly' ? '今月の総収入' : '全体の総収入'}
          </h3>
          <p className="text-3xl font-bold text-green-600">
            ¥{Math.round(viewType === 'monthly' ? totalIncome : totalAllIncome).toLocaleString()}
          </p>
        </div>
      </div>
    </div>
  );
}
