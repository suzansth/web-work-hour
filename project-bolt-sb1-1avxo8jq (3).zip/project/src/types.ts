export interface WorkEntry {
  id: string;
  date: Date;
  companyName: string;
  hoursWorked: number;
  wages: number;
}

export interface WorkShift {
  date: Date;
  startTime: string;
  endTime: string;
  companyName: string;
}