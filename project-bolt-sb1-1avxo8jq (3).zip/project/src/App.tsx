import React, { useState, useEffect } from 'react';
import { WorkEntryForm } from './components/WorkEntryForm';
import { WorkList } from './components/WorkList';
import { MonthlyStats } from './components/MonthlyStats';
import { ShiftCalendar } from './components/ShiftCalendar';
import { WorkEntry, WorkShift } from './types';
import { startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';

export default function App() {
  const [entries, setEntries] = useState<WorkEntry[]>([]);
  const [shifts, setShifts] = useState<WorkShift[]>([]);
  const [selectedMonth, setSelectedMonth] = useState(() => startOfMonth(new Date()));

  // Filter entries for the selected month
  const monthlyEntries = entries.filter(entry =>
    isWithinInterval(entry.date, {
      start: startOfMonth(selectedMonth),
      end: endOfMonth(selectedMonth)
    })
  );

  const handleAddEntry = (entry: WorkEntry) => {
    setEntries(prev => [...prev, entry]);
  };

  const handleAddShift = (shift: WorkShift) => {
    setShifts(prev => [...prev, shift]);
  };

  const handleMonthChange = (date: Date) => {
    setSelectedMonth(startOfMonth(date));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">WORK HOUR</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <WorkEntryForm onSubmit={handleAddEntry} />
            <MonthlyStats 
              entries={monthlyEntries} 
              selectedMonth={selectedMonth}
              allEntries={entries}
              onMonthChange={handleMonthChange}
            />
          </div>
          
          <div className="space-y-8">
            <ShiftCalendar 
              shifts={shifts} 
              onAddShift={handleAddShift}
              selectedMonth={selectedMonth}
              onMonthChange={handleMonthChange}
            />
            <WorkList entries={monthlyEntries} />
          </div>
        </div>
      </div>
    </div>
  );
}